DSSMM folder artwork

Copy SYSTEM into the root of your SD card, merging folders. The pack contains
# and A through Z and game system folder art: Title 120x80 in SYSTEM/IMGS/CUSTOM; Box 80x80 in
SYSTEM/IMGS2/CUSTOM. Choose Title or Box artwork in Interface settings.
Existing CUSTOM files with these names are your overrides: keep them if desired.

Matches the complete folder name anywhere on the card. A folder named "E" uses
E.bmp whether it is at the root or nested inside another folder. Names such as
"Europe" or "E Games" do not match to E.bmp. No ROM filename/header artwork is replaced.
DSSMM SuperFW 588 or newer supports directory CUSTOM art.

BMP files use DSSCC RGB555/DST1 transparency; empty canvas is transparent in the
kernel. PNG versions retain standard alpha transparency for editing/previews.
Letter bitmap credit: DS Style / DSSMM DE ASCII asset, Apache-2.0. Closed-folder
geometry and pack generator: DSSMM contributors, GPL-3.0-or-later. See repository
superfw/docs/FONT-PORT.md and retained component licenses.
